CREATE VIEW orders_products_customers AS
SELECT customers.name AS customer_name,
       products.product_name,
       products.category,
       order_items.quantity,
       products.price,
       orders.order_date
FROM order_items
         JOIN orders ON order_items.order_id = orders.id
         JOIN products ON order_items.product_id = products.id
         JOIN customers ON orders.customer_id = customers.id;

